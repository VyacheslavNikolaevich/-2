﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex121
{

    /// <summary>
    /// Класс HeroAgillity
    /// </summary>
    
    class HeroAgillity
    {
        private static int number;
        private static Random r;

        private string name;
        private int hp;
        private int maxHp;

        private int energy;
        private int maxEnergy;

        static HeroAgillity()
        {
            HeroAgillity.number = 0;
            HeroAgillity.r = new Random();

        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// 
        public HeroAgillity(string Name, int hp, int Energy)
        {

        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        
        public HeroAgillity()
        {

        }

        /// <summary>
        /// Метод, описывающий атаку
        /// </summary>       
        
        public int Attack()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>
        
        public string GetInfo()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Метод, описывающий логику получения лечения
        /// </summary>

        public void ToBeHealed(int Hp)
        { this.hp = Hp + this.hp > this.maxHp ? }        
         
        /// <summary>
        /// Метод, описывающий логику получения урона
        /// </summary>        

        public void GetDamage(int Damage)
        {
            if (this.hp - Damage > 0) { this.hp -= Damage; }
            //else { Die(); }
        }



    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex121
{
    /// <summary>
    /// Класс HeroIntelligence
    /// </summary>

    class HeroIntelligence
    {
        private static int number;
        private static Random r;

        private string name;
        private int hp;
        private int maxHp;

        private int casting;
        private int mp;
        private int maxMp;

        static HeroIntelligence()
        {
            HeroIntelligence.number = 0;
            HeroIntelligence.r = new Random();
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        
        public HeroIntelligence(string Name, int Hp, int Mp)
        {

        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        
        public HeroIntelligence()
        {

        }

        /// <summary>
        /// Метод, описывающий атаку
        /// </summary>

        public int Attack()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Метод, описывающий лечение
        /// </summary>
        
        public int Healing()
        {

        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>
        
        public string GetInfo()
        {

        }

        /// <summary>
        /// Метод, описывающий логику получения лечения
        /// </summary>

        public void ToBeHealed(int Hp)
        { this.hp = Hp + this.hp > this.maxHp ? }        
        
        /// <summary>
        /// Метод, описывающий логику получения урона
        /// </summary>        

        public void GetDamage(int Damage)
        {
            if (this.hp - Damage > 0) { this.hp -= Damage; }
            //else { Die(); }
        }


    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex121
{
    public class Readme
    {
        https://dota2.ru/heroes/
        https://steamcdn-a.akamaihd.net/steam/apps/570/ss_d0f973ce376ca5b6c08e81cb035e86ced105fa9.1920x1080.jpg?t=154
        http://mmobom.ru/uploads/editor/images/user_1920/8942/OBw5GZg.jpg
    }
}
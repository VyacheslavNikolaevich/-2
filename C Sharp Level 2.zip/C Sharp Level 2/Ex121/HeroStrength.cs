﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex121
{
    /// <summary>
    /// Класс HeroStrength
    /// </summary>

    class HeroStrength
    {
        private static int number;
        private static Random r;

        private string name;
        private int hp;
        private int maxHp;

        private int castihg;
        private int rage;
        private int maxRage;

        static HeroStrength()
        {
            HeroStrength.number = 0;
            HeroStrength.r = new Random();
        }
        
        /// <summary>
        /// Конструктор
        /// </summary>
        
        public HeroStrength(string Name, int Hp, int Rage)
        {

        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        
        public HeroStrength()
        {

        }

        /// <summary>
        /// Метод, описывающий атаку
        /// </summary>
        
        public int Attack()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>
        
        public string GetInfo()
        {

        }

        /// <summary>
        /// Метод, описывающий логику лечения
        /// </summary>
         
        public void ToBeHealed(int Hp)
        { this.hp = Hp + this.hp > this.maxHp ? }       
        
        /// <summary>
        /// Метод, описывающий логику получения урона
        /// </summary>     
        
        public void GetDamage(int Damage)
        {
            if (this.hp - Damage > 0) { this.hp -= Damage; }
            //else { Die(); }
        }


    }
}
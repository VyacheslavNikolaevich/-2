﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex21
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. Написать метод возвращающий минимальное из трех чисел.

            Console.Write("a = "); int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("b = "); int b = Convert.ToInt32(Console.ReadLine());
            Console.Write("c = "); int c = Convert.ToInt32(Console.ReadLine());

            int min = MinValue(a, b, c);

            Console.WriteLine(min);
            Console.ReadKey();
        }

        /// <summary>
        /// метод, возвращающий минимальное из трех чисел
        /// </summary>
        /// <param name="a">первое число</param>
        /// <param name="b">второе число</param>
        /// <param name="c">третье число</param>
        /// <returns>результат</returns>

        private static int MinValue(int a, int b, int c)
        {
            int min;

            if (a < b && a < c)
            {
                min = a;
            }
            else
            {
                if (b < c) { min = b; }
                else { min = c; }
            }

            return min;

            

            
        }


    }
}

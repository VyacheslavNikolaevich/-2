﻿using Ex010;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex011
{
    class Program
    {
        static void Main(string[] args)
        {
            Robot robot1 = new Robot(Name: "Имя_1", Level: 1);
            Robot robot2 = new Robot(Name: "Имя_1", Level: 1);
            Robot robot3 = new Robot(Name: "Имя_1", Level: 1);
            Robot robot4 = new Robot(Name: "Имя_1", Level: 1);
            Robot robot5 = new Robot(Name: "Имя_1", Level: 1);

            Console.WriteLine($"{robot1.Name}{robot1.Level}");
            Console.WriteLine($"{robot2.Name}{robot2.Level}");
            Console.WriteLine($"{robot3.Name}{robot3.Level}");
            Console.WriteLine($"{robot4.Name}{robot4.Level}");
            Console.WriteLine($"{robot5.Name}{robot5.Level}");

            robot1.PowerOn();

            robot1.PowerOff();

        }

       

       
    }
}

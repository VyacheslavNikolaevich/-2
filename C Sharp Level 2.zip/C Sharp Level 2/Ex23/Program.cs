﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex23
{
    class Program
    {
        static void Main(string[] args)
        {
            // С клавиатуры вводятся числа, пока не будет веден 0. 
            // Подсчитать сумму всех нечетных положительных чисел.

            int sum = SumNumb();

            Console.WriteLine(sum);
            Console.ReadKey();
        }

        /// <summary>
        /// Метод подсчета суммы всех нечетных положительных чисел.
        /// </summary>
        /// <returns>результат</returns>

        private static int SumNumb()
        {
            int sum = 0;
            while (true)
            {
                Console.Write("Введите число: "); int a = Convert.ToInt32(Console.ReadLine());
                if (a == 0) break;
                if (a > 0 && a % 2 == 1) sum += a;
            }

            return sum;
        }
    }
}

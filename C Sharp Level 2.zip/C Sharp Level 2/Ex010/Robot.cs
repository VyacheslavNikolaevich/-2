﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex010
{
    public class Robot
    {
        /// <summary>
        /// Уровень робота
        /// </summary>

        public int Level { get; set; }

        /// <summary>
        /// Имя робота
        /// </summary>

        public string Name { get; set; }

        /// <summary>
        /// Создание робота
        /// </summary>

        public Robot(string Name, int Level)
        {

        }

        #region Методы вкл\выкл подсистем

        /// <summary>
        /// Загрузка BIOS
        /// </summary>

        public void StartBIOS() { Console.WriteLine("StartBIOS..."); }

        /// <summary>
        /// Загрузка OS
        /// </summary>

        public void StartOS() { Console.WriteLine("StartOS..."); }

        /// <summary>
        /// Приветствие
        /// </summary>

        public void SayHi() { Console.WriteLine("Hello world..."); }

        /// <summary>
        /// Выгрузка BIOS
        /// </summary>

        public void StopBIOS() { Console.WriteLine("StopBIOS..."); }

        /// <summary>
        /// Выгрузка OS
        /// </summary>

        public void StopOS() { Console.WriteLine("StopOS..."); }

        /// <summary>
        /// Прощание
        /// </summary>

        public void SayBye() { Console.WriteLine("Bye..."); }

        /// <summary>
        /// Работа
        /// </summary>

        public void Work() { Console.WriteLine("Working..."); }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex24
{
    class Program
    {
        static bool Check(string Login, string Password)
        {
            return (Login == "root" && Password == "GreekBrains");
        }
        static void Main(string[] args)
        {
            // Реализовать метод проверки логина и пароля.
            // На вход метода подается логин и пароль.
            // На выходе истина, если прошел авторизацию, и ложь, если не прошел.
            // (Логин: root, Password: GreekBrains).
            // Используя метод проверки логина и пароля, написать программу:
            // пользователь вводит логин и пароль, программа пропускает его
            // дальше или не пропускает.С помощью цикла do while ограничить ввод пароля тремя попытками. 

            for (int i = 0; i < 3; i++)
            {
                Console.Write("Введите логин: "); string login = Console.ReadLine();
                Console.Write("Введите пароль: "); string password = Console.ReadLine();

                if (Check(login, password))
                {
                    Console.WriteLine("Добро пожаловать ");
                    break;
                }
                else
                {
                    Console.WriteLine("Попробуйте еще раз");
                    Console.ReadKey();

                }
            }
        }
    }
}

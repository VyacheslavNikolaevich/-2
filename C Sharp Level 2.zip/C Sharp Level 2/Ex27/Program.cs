﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex27
{
    class Program
    {
        static void FOR(int a, int b)
        {
            Console.Write($"{a} ");
            if (a < b) FOR(a + 1, b);
        }

       

        static void Main(string[] args)
        {
            // а) Разработать рекурсивный метод, который выводит на экран числа от а до b(a < b).
            // б) Разработать рекурсивный метод, который считает сумму чисел от а до b.

            FOR(1, 10);
            Console.ReadKey();

            



        }
    }
}

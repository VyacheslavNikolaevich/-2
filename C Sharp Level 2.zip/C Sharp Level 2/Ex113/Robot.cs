﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex113
{
    /// <summary>
    /// Состояние робота
    /// </summary>

    enum State
    {
        /// <summary>
        /// Включен
        /// </summary>

        PowerOn,

        /// <summary>
        /// Выключен
        /// </summary>

        PowerOff
    }

    public class Robot
    {
        private static int DefaultIndex;
        private static List<string> nameCol;

        /// <summary>
        /// Статический конструктор
        /// </summary>

        static Robot()
        {
            nameCol = new List<string>();
            DefaultIndex = 1;
        }

        private Robot(string Name, int Level)
        {
            if ((Name == String.Empty || char.IsDigit(Name[0])) || Robot.nameCol.IndexOf(Name) != -1)
            { this.name = $"DefaultName_{Robot.DefaultIndex++ }"; }
            else { this.name = Name; }

            Robot.nameCol.Add(this.name); this.level = Level; this.setState = State.PowerOff;
        }

        #region ctor v1.0

        //public Robot(string Name)
        //{
        //if ((Name == String.Empty || char.IsDigit(Name[0])) || Robot.nameCol.IndexOf(Name) != -1)
        //{ this.name = $"DefaultName_{Robot.DefaultIndex++}"; }
        //else { this.name = Name; }

        //Robot.nameCol.Add(this.name); this.Level = 1; this.setState = State.PowerOff;
        //}

        //public Robot()
        //{
        //this.name = $"DefaultName_{Robot.DefaultIndex++}";

        //Robot.nameCol.Add(this.name); this.level = 1; this.setState = State.PowerOff;
        //}

        #endregion

        #region ctor v2.0;        

        public Robot(string Name) : this(Name, 1) { /*this.Level = 1000;*/}

        public Robot() : this(String.Empty) { }

        #endregion

        #region Икапсуляция v 2.0

        private State setState;

        /// <summary>
        /// Включение / Выключение робота
        /// </summary>

        public void Power()
        {
            if (this.setState == State.PowerOn)
            {
                this.PowerOff();
                this.setState = State.PowerOff;
            }
            else
            {
                this.PowerOn();
                this.setState = State.PowerOn;
            }
        }

        #endregion

        #region Инкапсуляция v 1.0

        /// <summary>
        /// Метод включения
        /// </summary>

        public void PowerOn()
        {
            this.StartBIOS();
            this.StartOS();
            this.SayHi();
        }

        /// <summary>
        /// Метод выключения
        /// </summary>

        public void PowerOff()
        {
            this.SayBye();
            this.StopOS();
            this.StopBIOS();
        }

        #endregion

        private int level;
        private string name;

        /// <summary>
        /// Уровень робота
        /// </summary>

        public int Level
        {
            get { return this.level; }
            private set { this.level = value; }
        }

        /// <summary>
        /// Имя робота
        /// </summary>

        public string Name
        {
            get { return this.name; }
            private set { this.name = value; }
        }

        public string GetName()
        {
            return this.name;
        }

        private void SetName(string value)
        {
            this.name = value;
        }

        public void Rename(string NewName/*,User LoginPassword*/)
        {
            //if (LoginPassword...)
            this.name = NewName;
        }
    }
}
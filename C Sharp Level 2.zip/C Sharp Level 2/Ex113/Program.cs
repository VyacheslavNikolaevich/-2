﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex113
{
    class Program
    {
        static void Main(string[] args)
        {
            Robot robot3 = new Robot();
            Console.WriteLine($"robot >>> {robot3.Name}{robot3.Level}");

            robot3.Power();

            Robot robot1 = new Robot("robot_1");
            Robot robot2 = new Robot("robot_1");

            Robot robot4 = new Robot("robot_1");
            Robot robot5 = new Robot("robot_1");

            robot1.Power(); Console.WriteLine();
            robot1.Power(); Console.WriteLine();
            robot1.Power(); Console.WriteLine();
            robot1.Power(); Console.WriteLine();

            Console.WriteLine($"robot1 >>> {robot1.Name}{robot2.Level}");
            Console.WriteLine($"robot2 >>> {robot2.Name}{robot2.Level}");
            Console.WriteLine($"robot3 >>> {robot3.Name}{robot3.Level}");
            Console.WriteLine($"robot4 >>> {robot4.Name}{robot4.Level}");

            Console.WriteLine($"robot5 >>> {robot5.Name}{robot5.Level}");
        }
    }
}

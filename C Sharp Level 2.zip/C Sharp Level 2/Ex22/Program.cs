﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex22
{
    class Program
    {
        static void Main(string[] args)
        {
            // Написать метод подсчета количества цифр числа.

            Console.Write("a = "); int a = Convert.ToInt32(Console.ReadLine());

            int count = Counter( a);

            Console.WriteLine(count);
            Console.ReadKey();
        }

        /// <summary>
        /// метод, подсчета количества цифр числа
        /// </summary>
        /// <param name="a">ввести число</param>
        /// <returns>получение результата</returns>

        private static int Counter( int a)
        {
            int count = 0;
            if (a == 0) count = 1;
            while (a != 0)
            {
                a = a / 10;
                count++;
            }

            return count;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex122
{
    public class HeroBase
    {
        protected static int number;
        protected static Random r;

        protected string name;
        protected int hp;
        protected int maxHp;

        public string Name { get { return name; } private set { name = value; } }

        static HeroBase()
        {

        }

        /// <summary>
        /// Конструктор
        /// </summary>       
        
        public HeroBase(string Name, int Hp)
        {

        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        
        public HeroBase()
        {

        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>
        
        public virtual string GetInfo()
        {
            return $"Name: {this.name,8} Hp: {this.hp, 4} Type: {this.GetType()} ";
        }

        /// <summary>
        /// Метод, описывающий логику получения лечения
        /// </summary>       

        public void ToBeHealed(int Hp)
        { this.hp = Hp + this.hp > this.maxHp ? }

        /// <summary>
        /// Метод, описывающий логику получения урона
        /// </summary>        

        public void GetDamage(int Damage)
        {
            if (this.hp - Damage > 0) { this.hp -= Damage; }
            //else { Die(); }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex122
{
    class HeroAgillity : HeroBase
    {
        private int energy;
        private int maxEnergy;

        /// <summary>
        /// Конструктор
        /// </summary>        

        public HeroAgillity(string Name, int Hp, int Energy)
        {

        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>

        public HeroAgillity()
        {

        }

        /// <summary>
        /// Метод, описывающий атаку
        /// </summary>
        
        public int Attack()
        {

        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>        

        public string GetInfo()
        {
            return base.GetInfo() + $" Energy: {this.energy}";
        }
    }

   
}
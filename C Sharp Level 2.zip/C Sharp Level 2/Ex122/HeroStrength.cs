﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex122
{
    class HeroStrength 
    {
        private int rage;
        private int maxRage;
        private int casting;

        /// <summary>
        /// Конструктор
        /// </summary>        

        public HeroStrength(string Name, int Hp, int Rage)
        {

        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        
        public HeroStrength()
        {

        }

        /// <summary>
        /// Метод, описывающий атаку
        /// </summary>        

        public int Attack()
        {
            if(this.rage - this.casting >= 0) { this.rage -= this.casting; return HeroStrength.r.Next(20, 30); }
            else { return 0; }
        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>        

        public string GetInfo()
        {
            return base.GetInfo() + $" Rage : {this.rage}"; 
        }
    }
}
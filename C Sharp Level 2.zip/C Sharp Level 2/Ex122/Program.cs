﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex122
{
    public class Program
    {
        

        static void Main(string[] args)
        {

            #region Ex0 Exs

            Console.WriteLine("----");
            HeroAgillity heroAgillity = new HeroAgillity();
            HeroIntelligence heroIntelligence = new HeroIntelligence();
            HeroStrength heroStrength = new HeroStrength();

            Console.WriteLine(heroAgillity.GetInfo());
            Console.WriteLine(heroIntelligence.GetInfo());
            Console.WriteLine(heroStrength.GetInfo());
            Console.WriteLine();

            heroAgillity.GetDamage(heroStrength.Attack());
            Console.WriteLine(heroAgillity.GetInfo());

            heroAgillity.GetDamage(heroStrength.Attack());
            Console.WriteLine(heroAgillity.GetInfo());

            heroAgillity.ToBeHealed(heroIntelligence.Healing());
            Console.WriteLine(heroAgillity.GetInfo());

            heroAgillity.ToBeHealed(heroIntelligence.Healing());
            Console.WriteLine(heroAgillity.GetInfo());

            Console.ReadLine();
            Console.WriteLine();

            #endregion

            #region Ex1 Полиморфизм

            HeroBase hero = new HeroBase();
            Console.WriteLine(hero.GetInfo());

            hero = new HeroAgillity();
            Console.WriteLine(hero.GetInfo());

            HeroAgillity agillity = new HeroAgillity();
            Console.WriteLine(agillity.GetInfo());

            hero = new HeroIntelligence();
            Console.WriteLine(hero.GetInfo());

            hero = new HeroStrength();
            Console.WriteLine(hero.GetInfo);

            #endregion
        }
    }
}
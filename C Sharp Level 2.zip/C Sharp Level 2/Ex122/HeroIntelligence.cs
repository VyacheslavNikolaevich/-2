﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex122
{
    class HeroIntelligence : HeroBase
    {
        private int mp;
        private int maxMp;
        private int casting;
        
        /// <summary>
        /// Конструктор
        /// </summary>
        
        public HeroIntelligence(string Name, int Hp, int Mp) : base(Name, Hp)
        {
            this.casting = 10;
            this.mp = Mp;
            this.maxMp = Mp;
        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>

        public HeroIntelligence()
        {

        }

        /// <summary>
        /// Метод, описывающий атаку
        /// </summary>       

        public int Attack()
        {

        }

        /// <summary>
        /// Метод, описывающий лечение
        /// </summary>       

        public int Healing()
        {

        }

        /// <summary>
        /// Метод, описывающий информацию о герое
        /// </summary>        

        public string GetInfo()
        {
            return base.GetInfo() + $" Mp: {this.mp}";
        }
    }
}
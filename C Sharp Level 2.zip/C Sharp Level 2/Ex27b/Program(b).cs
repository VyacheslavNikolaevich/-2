﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex27b
{
    class Program
    {
        static void FOR(int a, int b)
        {
            Console.Write($"{a} ");
            if (a < b) FOR(a + 1, b);
        }

        static int SUM(int a, int b)
        {
            return a < b ? a + SUM(a + 1, b) : a;
        }

        static void Main1(string[] args)
        {
            Console.WriteLine(SUM(10, 12));
            Console.ReadKey();
        }
        
    }
}
